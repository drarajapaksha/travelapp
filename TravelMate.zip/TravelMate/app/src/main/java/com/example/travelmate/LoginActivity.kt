package com.example.travelmate

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val username = findViewById<TextView>(R.id.username)
        val password = findViewById<TextView>(R.id.password)
        val login = findViewById<Button>(R.id.login)
        val signup = findViewById<Button>(R.id.signup)

        login.setOnClickListener()
        {
            if(!username.text.isNullOrEmpty() && !password.text.isNullOrEmpty()){
                val intent = Intent(this,galleryActivity::class.java)
                startActivity(intent)
            }
            else
            {
                val toast = Toast.makeText(applicationContext,"Login Failed", Toast.LENGTH_LONG).show()

            }

        }
    }
}