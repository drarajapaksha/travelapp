package com.example.travelmate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.ImageView
import android.widget.ScrollView


class galleryActivity : AppCompatActivity() {

    lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        val scroll1 = findViewById<ScrollView>(R.id.scrollView2)
        //scroll1.movementMethod = ScrollingMovementMethod()

        val scroll2 = findViewById<ScrollView>(R.id.scrollView3)
        //scroll2.movementMethod = ScrollingMovementMethod()
    }
}